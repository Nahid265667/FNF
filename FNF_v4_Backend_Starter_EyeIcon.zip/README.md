# FNF

FNF is a starter interface for a modern social network, messaging, mail, wallet and referral platform.

## Included
- Responsive starter page
- Password show/hide eye button
- Basic project structure

This is a frontend starter only; real authentication, database, wallet and referral services should be connected securely on a backend.
