# FNF One MVP v5 — Meet Foundation

Adds the FNF Meet user flow: Create Meeting, Join Meeting, meeting ID, mic/camera controls, chat/share placeholders, and leave.

This is a front-end prototype. Real multi-person video requires secure backend and real-time WebRTC/SFU infrastructure.
